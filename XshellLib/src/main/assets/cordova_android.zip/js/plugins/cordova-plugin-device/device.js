cordova.define("cordova-plugin-device.device", function(require, exports, module) { 


var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */

module.exports = {
    //获取设备信息
	getInfo : function(successCallBack) {
        exec(successCallBack, null, "DevicePlugin", "getInfo", []);
    },
	//开始录音
	startRecord : function() {
		exec(null, null, "RecordPlugin", "startRecord", []);
	},
	//结束录音
	endRecord : function(successCallBack) {
		exec(successCallBack, null, "RecordPlugin", "endRecord", []);
	},
	//显示键盘
	showKeyboard : function(type, defaultKeyboard, successCallBack) {
		if (arguments.length == 2) {
			successCallBack = defaultKeyboard;
		}
		exec(successCallBack, null, "DevicePlugin", "showKeyboard", [type, defaultKeyboard]);
	},
	//获取地理位置
	location : function(successCallBack) {
		exec(successCallBack, null, "DevicePlugin", "location", []);
	},
	//扫描二维码
	scanQRCode : function(successCallBack) {
		exec(successCallBack, null, "DevicePlugin", "scanQRCode", []);
	},
	//指纹识别
	touchid : function(failureCallBack) {
		exec(null, failureCallBack, "DevicePlugin", "touchid", []);
	},
	//横竖屏切换
	changeOrientation : function(type) {
		exec(null, null, "DevicePlugin", "changeOrientation", [type]);
	},
	//拨打电话
	call : function(phonenum) {
		exec(null, null, "DevicePlugin", "call", [phonenum]);
	},
   statusBarStyle : function (param) {
      exec(null, null, "DevicePlugin", "statusBarStyle", [param]);
},
     getPushInfo  : function (successCallBack) {
            exec(successCallBack, null, "AppNativePlugin", "getPushInfo", []);
     },
	showMapInfo : function(successCallBack) {
		exec(successCallBack, null, "DevicePlugin", "showMapInfo", []);
	},
	
	camera : function(successCallBack) {
		exec(successCallBack, null, "DevicePlugin", "camera", []);
	}
	,
	
	album : function(param,successCallBack) {
		exec(successCallBack, null, "DevicePlugin", "album", [param]);
	}
	,
	
	map : function(adress,successCallBack) {
		exec(successCallBack, null, "DevicePlugin", "map", [adress]);
	},
	
	distance : function(type,pos1,posion2,successCallBack) {
		exec(successCallBack, null, "DevicePlugin", "distance", [type,pos1,posion2]);
	}
};

});
