cordova.define("cordova-plugin-sm2Plugin.sm2.js", function(require, exports, module) {

var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */
module.exports = {
    
    sm2Plugin: function(callback,plainText,secretkey) {
        exec(
        		callback,
        		null,
        		'sm2Plugin',
        		'sm2',
        		[{'plainText':plainText,'secretkey':secretkey}]
        	);
    }
};

});
