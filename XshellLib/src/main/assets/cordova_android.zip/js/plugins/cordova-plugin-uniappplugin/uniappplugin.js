cordova.define("cordova-plugin-uniappplugin.uniappplugin", function(require, exports,
		module) {

	var exec = require('cordova/exec');
	module.exports = {
        //查询本地数据
        getData : function (tableName, keyStr, successCallBack) {
            exec(successCallBack, null, "DataLocalityPlugin", "getData", [tableName, keyStr]);
        },
        //写入本地数据
        writeData : function (tableName, key, value) {
            exec(null, null, "DataLocalityPlugin", "writeData", [tableName, key, value]);
        },
        //保存图片
        getImage : function (imageurl, successCallBack, failureCallBack) {
            exec(successCallBack, failureCallBack, "DataLocalityPlugin", "getImage", [imageurl]);
        },
        //XLog
        recordLog : function (jsonString) {
            exec(null, null, "XLogPlugin", "recordLog", [jsonString]);
        },
        userrecord : function (record) {
            exec(null, null, "XLogPlugin", "userrecord", [record]);
        },
        //微信支付
        wxpay: function(payDetailInfo, successCallBack, failureCallBack) {
            exec(successCallBack, failureCallBack, "WeiXinPlugin", "wxpay", [payDetailInfo]);
        },
        //调用相册或者相机
        takePicture : function (uploadUrl, successCallBack, failureCallBack) {
            exec(successCallBack, failureCallBack, "SelectPicturePlugin", "takePicture", [uploadUrl]);
        },
        //腾讯云直播与点播
        livePlay: function (playUrl, playType, filePath, successCallBack, failedCallBack) {
            exec(successCallBack, failedCallBack, "LiveVideoPlugin", "livePlay", [playUrl,playType, filePath]);
         },
        //写入本地数据
        setArr : function (key, valueArr) {
            exec(null, null, "DataLocalityPlugin", "setArr", [key, valueArr]);
        },
        //查询本地数据
        getArr : function (key, pageIndex, pageNum, sort, successCallBack, failureCallBack) {
            if (arguments.length == 3) {
                key = arguments[0];
                successCallBack = arguments[1];
                failureCallBack = arguments[2];
            } else if (arguments.length == 4) {
                key = arguments[0];
			    sort = arguments[1];
			    successCallBack = arguments[2];
			    failureCallBack = arguments[3];
            }
            exec(successCallBack, failureCallBack, "DataLocalityPlugin", "getArr", [key, pageIndex, pageNum, sort]);
        },

       //将Map集合写入本地数据
        setMap : function (key, value) {
            exec(null, null, "DataLocalityPlugin", "setMap", [key, value]);
        },
        
       //查询Map本地数据
        getMap : function (key, successCallBack, failureCallBack) {
             exec(successCallBack, failureCallBack, "DataLocalityPlugin", "getMap", [key]);
        },
        //存储数据
        setArrData: function (key, valueArr) {
            exec(null, null, "DataLocalityPlugin", "setArrData", [key, valueArr]);
        },
        //取数据
        getArrData: function (key, id, number, flag, successCallBack, failedCallBack) {
            exec(successCallBack, failedCallBack, "DataLocalityPlugin", "getArrData", [key, id, number, flag]);
        },
        //取数据
        getArrDataByID : function (key, idStr, successCallBack, failedCallBack) {
            exec(successCallBack, failedCallBack, "DataLocalityPlugin", "getArrDataByID", [key, idStr]);
        },
        //获取缓存文件大小
        getCacheSize: function (successCallBack) {
            exec(successCallBack, null, "DataLocalityPlugin", "getCacheSize", []);
        },
        //取数据
        deleteData : function (days) {
           if(days == null || days == undefined){
		       days = -1;
	       }
            exec(null, null, "DataLocalityPlugin", "deleteData", [days]);
        },
        //取key对应的所有数据
        getArrAllData : function (key, sort, successCallBack, failedCallBack) {
            exec(successCallBack, failedCallBack, "DataLocalityPlugin", "getArrAllData", [key, sort]);
        },
        //删除key对应的所有数据
        deleteDataByKey : function (key) {
            exec(null, null, "DataLocalityPlugin", "deleteDataByKey", [key]);
        },
        alipay : function (orderString, successCallBack, failedCallBack) {
            exec(successCallBack, failedCallBack, "AlipayPlugin", "alipay", [orderString]);
        },
        commentbox : function (object, successCallBack) {
            exec(successCallBack, null, "CommentBoxPlugin", "commentbox", [object]);
        },
        getUserInfo : function (param) {
            exec(null, null, "XLogPlugin", "getUserInfo", [param]);
        },
        //初始化音视频通话
        initUCSCall : function (token) {
            exec(null, null, "AudioAndVideoPlugin", "initUCSCall", [token]);
        },
        //音视频通话
        audioandvideocall : function (type, param) {
            exec(null, null, "AudioAndVideoPlugin", "audioandvideocall", [type, param]);
        },
        //图片浏览器
        pictureBrowser : function(imgURLArr, url) {
            exec(null, null, "PictureBrowserPlugin", "pictureBrowser", [imgURLArr, url]);
        },

		play : function(playUrl, successCallBack, failureCallBack) {
            exec(successCallBack, failureCallBack, "LiveVideoPlugin", "play", [playUrl]);
        },
	     authorizeIsOpen : function(flag,successCallBack) {
            exec(successCallBack,null,"NativeSetPlugin", "authorizeIsOpen",[flag]);
        },
      toAuthorizeSet : function(flag) {
                   exec(null,null,"NativeSetPlugin", "toAuthorizeSet",[flag]);
               },

	  iapppay : function (payInfo, successCallBack, failureCallBack) {
                exec(successCallBack, failureCallBack, "IappayPlugin", "iapppay", [payInfo]);
            },
      openaccount : function (param, failureCallBack) {
                exec(null, failureCallBack, "NativeSetPlugin", "openaccount", [param]);
            },

     cchelper : function (param, failureCallBack) {
            exec(null, failureCallBack, "NativeSetPlugin", "cchelper", [param]);
        },
		
     startRecord : function (param, successCallBack) {
            exec(successCallBack, null, "NativeSetPlugin", "startRecord", [param]);
        },
	 endRecord : function (param, successCallBack) {
            exec(successCallBack, null, "NativeSetPlugin", "endRecord", [param]);
        },
		
    speechStart : function (param, successCallBack) {
            exec(successCallBack, null, "NativeSetPlugin", "speechStart", [param]);
        }			




        // //隐藏状态栏
        // statusBarHide : function () {
        //     exec(null, null, "StatusBar", "statusBarHide", []);
        // },
        // //显示状态栏
        // statusBarShow : function () {
        //     exec(null, null, "StatusBar", "statusBarShow", [])
        // }
	};

});
