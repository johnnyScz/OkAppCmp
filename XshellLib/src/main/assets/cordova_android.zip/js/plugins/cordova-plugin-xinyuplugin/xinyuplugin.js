cordova.define("cordova-plugin-xinyuplugin.xinyuplugin", function(require, exports,module) {

	var exec = require('cordova/exec');
	module.exports = {
		//开始视频播放
		startSmartPlayer : function(id) {
			exec(null, null, "SmartPlayerPlugin", "startSmartPlayer", [ id ]);
		},
		//竖屏
		startSmartPlayerVertical : function(id) {
            exec(null, null, "SmartPlayerPlugin", "startSmartPlayerVertical", [ id ]);
        },
		//cc视频回放  roomId 房间号， liveId  直播号
        CCVideoPlayBack : function(roomId,liveId) {
            exec(null, null, "CCPlayerPlugin", "CCVideoPlayBack", [roomId,liveId]);
        },
        CCVideoPlayBackVertical : function(roomId,liveId) {
            exec(null, null, "CCPlayerPlugin", "CCVideoPlayBackVertical", [roomId,liveId]);
        },
        //cc视频直播 roomId 房间号
        CCVideoLive : function(roomId) {
            exec(null, null, "CCPlayerPlugin", "CCVideoLive", [roomId]);
        },
        CCVideoLiveVertical : function(roomId) {
            exec(null, null, "CCPlayerPlugin", "CCVideoLiveVertical", [roomId]);
        },
        //base64字符串转换成图片保存
        base64ConvertToImageAndSave : function(base64Str,filePath,fileName, success, failure) {
            exec(success, failure, "ConvertToImagePlugin","base64ConvertToImageAndSave", [base64Str,filePath,fileName]);
        },
            //打开pdf  filepath 文件的地址
        openPDF : function(filePath,emailAddr,emailTitle, success, failure) {
            exec(success, failure, "OpenPDFPlugin", "openPDF", [filePath,emailAddr,emailTitle]);
        },
        toCommentOn: function() {
            exec(null, null, "ToCommentPlugin", "toCommentOn", [{}]);
        },
        dataRequest : function(url,socketurl,callbackName) {
            exec(null, null, "DataManagementPlugin", "dataRequest", [url,socketurl,callbackName]);
         },
        PictureBrowser : function(imageUrl,url) {
            exec(null, null, "PictureBrowserPlugin", "picturebrowser", [imageUrl,url]);
        },



        //密码框  callbackName 回调函数的名字
        inputPassword: function (callbackName) {
            exec(null, null, "InputPasswordPlugin", "inputPassword", [callbackName]);
        },
        //密码是否正确
        passwordState: function (state) {
            exec(null, null, "InputPasswordPlugin", "passwordState", [state]);
        },
        //打开socket url地址
        openWebSocket: function(url,successCallBack,failedCallBack) {
               exec(successCallBack, failedCallBack, "WebSocketPlugin", "openWebSocket", [url]);
        },
        //关闭socket
        closeWebSocket: function(successCallBack,failedCallBack) {
               exec(successCallBack, failedCallBack, "WebSocketPlugin", "closeWebSocket", []);
        },
        //通过websocket发送信息
        sendMessage: function(content,successCallBack,failedCallBack) {
               exec(successCallBack, failedCallBack, "WebSocketPlugin", "sendMessage", [content]);
        },
        //注册
        registerPush: function(content,successCallBack,failedCallBack) {
               exec(successCallBack, failedCallBack, "WebSocketPlugin", "registerPush", [content]);
        },
        //订阅
        subscribePush: function(content, callbackName) {
              exec(null, null, "WebSocketPlugin", "subscribePush", [content,callbackName]);
         },
        //检查app更新
        checkUpdateApp: function() {
              exec(null, null, "CheckUpdateAppPlugin", "checkUpdate", []);
        },
        //检查缓存大小
        getCacheSize: function(rootPath, successCallBack, failedCallBack) {
            exec(successCallBack, failedCallBack, "ClearCachePlugin", "getCacheSize", [rootPath]);
        },
        //清除相应的缓存
        clearCache: function(time, rootPath, successCallBack, failedCallBack){
            exec(successCallBack, failedCallBack, "ClearCachePlugin", "clearCache", [time,rootPath]);
        },
        //拨打电话
        callPhoneWithNumber: function (phoneNum) {
            exec(null, null, "CallPhonePlugin", "callPhoneWithNumber", [phoneNum]);
        },
        //显示单选框
        showSelectDialog: function (lastCode, data, successCallBack) {
            exec(successCallBack, null, "SelectDialogPlugin", "showSelectDialog", [lastCode, data]);
        },

        /*  //微信支付
        weiXinPayEntry: function(appId,APP_KEY,nonceStr,packageValue,partnerId,prepayId,timeStamp) {
                           //  alert("222222");
             exec(null, null, "WeiXinPayEntry", "weiXinPayEntry", [appId,APP_KEY,nonceStr,packageValue,partnerId,prepayId,timeStamp]);
        }
		*/

	};

});
