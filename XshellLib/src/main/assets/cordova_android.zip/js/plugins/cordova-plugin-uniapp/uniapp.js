cordova.define("cordova-plugin-uniapp.uniapp", function(require, exports,
		module) {

	var exec = require('cordova/exec');
	module.exports = {
        //打开新窗口
        openWindow : function (url, effict, successCallBack) {
            var type;
            if (arguments.length == 2) {
                type = -1;
                successCallBack = effict;
            } else {
                type = effict;
            }
            exec(successCallBack, null, "NativePlugin", "openWindow", [url, type]);
        },    
        pictureBrowser : function (param, url) {
            exec(null, null, "PictureBrowserPlugin", "pictureBrowser", [param, url]);
        }
		, beginCall : function (param,successCallBack) {
            exec(successCallBack, null, "AppNativePlugin", "beginCall", [param]);
        }
	   , getUserInfo : function (successCallBack) {
            exec(successCallBack, null, "AppNativePlugin", "getUserInfo", []);
        }
       , backNative : function () {
            exec(null, null, "AppNativePlugin", "backNative", []);
			
        }
		, chat : function (param,successCallBack) {
            exec(successCallBack, null, "AppNativePlugin", "chat", [param]);
        }	
	    , browser : function (param,successCallBack) {
            exec(successCallBack, null, "AppNativePlugin", "browser", [param]);
        }, 
		cchelper : function (param) {
            exec(null, null, "AppNativePlugin", "cchelper", [param]);
        }, 
		appStatus : function (successCallBack) {
            exec(successCallBack, null, "AppNativePlugin", "appStatus", []);
        }					
	};

});
