cordova.define("cordova-plugin-localstorageplugin.localstorageplugin", function(require, exports,
		module) {

	var exec = require('cordova/exec');
	module.exports = {
       
        //存储key-value数据
        setValue : function (key, value) {
            exec(null, null, "LocalstoragePlugin", "setValue", [key, value]);
        },
        //通过key取相应的数据
        getByKey : function (key, successCallBack, failureCallBack) {
            exec(successCallBack, failureCallBack, "LocalstoragePlugin", "getByKey", [key]);
        },
        //删除某条key对应的数据
        deleteValueByKey : function (key) {
            exec(null, null, "LocalstoragePlugin", "deleteValueByKey", [key]);
        },
        //删除某些key对应的数据
        deleteValueByKeys : function (keys) {
            exec(null, null, "LocalstoragePlugin", "deleteValueByKeys", [keys]);
        },
        //存储List数据
        setList : function (key, idArr, list) {
            exec(null, null, "LocalstoragePlugin", "setList", [key, idArr, list]);
        },
	
        todo : function (param, successCallBack) {
            exec(successCallBack, null, "LocalstoragePlugin", "todo", [param]);
        },
		
		 detail : function (param, successCallBack) {
            exec(successCallBack, null, "LocalstoragePlugin", "detail", [param]);
        },
		assign : function (param, successCallBack) {
            exec(successCallBack, null, "LocalstoragePlugin", "assign", [param]);
        },
      
        //删除所有类型的数据
        deleteAllData : function () {
            exec(null, null, "LocalstoragePlugin", "deleteAllData", []);
        }   
	};

});
