cordova.define("cordova-plugin-sm4Plugin.sm4.js", function(require, exports, module) {

var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */
module.exports = {
    
    sm4Plugin: function(callback,model,plainText,secretkey,iv) {
        exec(
        		callback,
        		null,
        		'sm4Plugin',
        		'sm4',
        		[{'model':model,'plainText':plainText,'secretkey':secretkey,'iv':iv}]
        	);
    }
};

});
