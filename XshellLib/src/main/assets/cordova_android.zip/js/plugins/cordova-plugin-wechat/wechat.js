cordova.define("cordova-plugin-wechat.wechat", function(require, exports, module) { 


var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */

module.exports = {
    //分享文本到朋友圈
	shareTextToFriend : function(text) {
        exec(null, null, "WeChatPlugin", "share", [{"flag" : "1", "content" : text, "friend" : 1}]);
    },
	//分享URL到朋友圈
	shareUrlToFriend : function(url, title, description) {
		exec(null, null, "WeChatPlugin", "share", [{"flag" : "2", "content" : url, "friend" : 1, "title" : title, "describe" : description}]);
	},
	//分享文本到对话
	shareTextToDialog : function(text) {
		exec(null, null, "WeChatPlugin", "share", [{"flag" : "1", "content" : text, "friend" : 2}]);
	},
	//分享URL到对话
	shareUrlToDialog : function(url, title, description) {
		exec(null, null, "WeChatPlugin", "share", [{"flag" : "2", "content" : url, "friend" : 2, "title" : title, "describe" : description}]);
	},
	//微信登录
	login : function(successCallBack) {
		exec(successCallBack, null, "WeChatPlugin", "login", []);
	}
	,
	//小程序分享
	shareToWeChatMin : function(params) {
		exec(null, null, "WeChatPlugin", "shareToWeChatMin", [params]);
	}
	
};

});
