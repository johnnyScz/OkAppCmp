cordova.define("cordova-plugin-xinyuNewBrowser.xinyuNewBrowser.js", function(require, exports, module) {

var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */
module.exports = {
    
    screenLandscape: function(callback,type) {
        	exec(
            		null,
            		null,
            		'xinyuNewBrowserPlugin',
            		'xinyuNewBrowser',
            		[{'url':url,'callbackName':callBackName}]
            	);

            exec(
            		null,
            		null,
            		'xinyuNewBrowserPlugin',
            		'closeNewBrowser',
            		[{}]
            	);
    }
};

});
