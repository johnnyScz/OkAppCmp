cordova.define("cordova-plugin-safety.safety", function(require, exports, module) { 


var exec = require('cordova/exec');

/**
 * Provides access to notifications on the device.
 */

module.exports = {
    //AES256加密
	aes256Encrypt : function(text, secretKey,successCallBack) {
        exec(successCallBack, null, "EncryptPlugin", "aes256Encrypt", [text,secretKey]);
    },
	//AES256解密
	aes256Decrypt : function(ciphertext,secretKey, successCallBack) {
		exec(successCallBack, null, "EncryptPlugin", "aes256Decrypt", [ciphertext,secretKey]);
	},
	//SM2加密
	sm2Encrypt : function(plaintext, secretKey, successCallBack) {
		exec(successCallBack, null, "SafetyPlugin", "sm2Encrypt", []);
	},
	//SM4加密
	sm4Encrypt : function(model, plaintext, secretKey, iv, successCallBack) {
        var mIv = 'QWESFGRTAFKVA234KFRI';
		if (arguments.length == 3) {
			successCallBack = iv;
		} else {
		    mIv = iv;
		}
		exec(successCallBack, null, "SafetyPlugin", "sm4Encrypt", [model, plaintext, secretKey, mIv]);
	},
	//手势密码
	openLock : function(iscreateLock) {
		exec(null, null, "NativePlugin", "openLock", [iscreateLock]);
	},
	resetLock : function () {
		exec(null, null, "NativePlugin", "resetLock", []);
	},
	//支付密码
	setPayPassword : function(successCallBack) {
		exec(successCallBack, null, "PayPasswordPlugin", "setPayPassword", []);
	},
	//支付密码状态
	payPasswordState : function(payStatus) {
		exec(null, null, "PayPasswordPlugin", "payPasswordState", [payStatus]);
	}
};

});
