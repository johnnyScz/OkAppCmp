    cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/org.apache.cordova.network-information/www/network.js",
        "id": "org.apache.cordova.network-information.network",
        "clobbers": [
            "navigator.connection",
            "navigator.network.connection"
        ]
    },
    {
        "file": "plugins/org.apache.cordova.network-information/www/Connection.js",
        "id": "org.apache.cordova.network-information.Connection",
        "clobbers": [
            "Connection"
        ]
    },
    {
        "file": "plugins/org.apache.cordova.splashscreen/www/splashscreen.js",
        "id": "org.apache.cordova.splashscreen.SplashScreen",
        "clobbers": [
            "navigator.splashscreen"
        ]
    },
    {
        "file": "plugins/cordova-plugin-inappbrowser/www/inappbrowser.js",
        "id": "cordova-plugin-inappbrowser.inappbrowser",
        "clobbers": [
            "cordova.InAppBrowser.open",
            "window.open"
        ]
    },
    {
        "file": "plugins/cordova-plugin-dialogs/www/notification.js",
        "id": "cordova-plugin-dialogs.notification",
        "merges": [
            "navigator.notification"
        ]
    },
    {
        "file": "plugins/cordova-plugin-dialogs/www/android/notification.js",
        "id": "cordova-plugin-dialogs.notification_android",
        "merges": [
            "navigator.notification"
        ]
    },
	{
        "file": "plugins/cordova-plugin-sqlite/www/SQLitePlugin.js",
        "id": "cordova-plugin-sqlite.SQLitePlugin",
        "clobbers": [
            "SQLitePlugin"
        ]
    },
    {
        "file": "plugins/cordova-plugin-xgbadge/xgbadge.js",
        "id": "cordova-plugin-xgbadge.xgbadge",
        "clobbers": [
            "navigator.getxgbadgeplugin"
        ]
    },
      {
          "file": "plugins/cordova-plugin-camera/www/CameraConstants.js",
           "id": "cordova-plugin-camera.Camera",
           "clobbers": [
               "Camera"
           ]
      },
      {
          "file": "plugins/cordova-plugin-camera/www/CameraPopoverOptions.js",
          "id": "cordova-plugin-camera.CameraPopoverOptions",
          "clobbers": [
              "CameraPopoverOptions"
          ]
      },
      {
          "file": "plugins/cordova-plugin-camera/www/Camera.js",
          "id": "cordova-plugin-camera.camera",
          "clobbers": [
              "navigator.camera"
          ]
      },
      {
          "file": "plugins/cordova-plugin-camera/www/CameraPopoverHandle.js",
          "id": "cordova-plugin-camera.CameraPopoverHandle",
          "clobbers": [
              "CameraPopoverHandle"
          ]
      },
      {
           "file": "plugins/cordova-plugin-xinyuplugin/xinyuplugin.js",
           "id": "cordova-plugin-xinyuplugin.xinyuplugin",
           "clobbers": [
               "navigator.xinyuPlugin"
           ]
      },
      {
          "file": "plugins/cordova-plugin-httpplugin/cordovaHTTP.js",
           "id": "cordova-plugin-cordovahttp-cordovahttp",
           "clobbers": [
               "CordovaHttpPlugin"
           ]
      },
	   {
        "file": "plugins/cordova-plugin-uniapp/uniapp.js",
        "id": "cordova-plugin-uniapp.uniapp",
        "clobbers": [
            "uniapp"
        ]
    },
    {
        "file": "plugins/cordova-plugin-localstorageplugin/localstorageplugin.js",
        "id": "cordova-plugin-localstorageplugin.localstorageplugin",
        "clobbers": [
            "uniapp.todo"
        ]
    },
    {
        "file": "plugins/cordova-plugin-device/device.js",
        "id": "cordova-plugin-device.device",
        "clobbers": [
            "uniapp.device"
        ]
    },
    {
        "file": "plugins/cordova-plugin-myfile/file.js",
        "id": "cordova-plugin-myfile.file",
        "clobbers": [
            "uniapp.file"
        ]
    },
    {
        "file": "plugins/cordova-plugin-wechat/wechat.js",
        "id": "cordova-plugin-wechat.wechat",
        "clobbers": [
            "uniapp.wechat"
        ]
    }

];
module.exports.metadata = 
// TOP OF METADATA
{
    "org.apache.cordova.network-information": "0.2.15",
    "org.apache.cordova.splashscreen": "1.0.0",
    "cordova-plugin-inappbrowser": "1.0.1",
    "cordova-plugin-dialogs": "1.1.1",
    "cordova-plugin-wxplugin": "1.0.0",
    "cordova-plugin-locationplugin": "1.0.0",
	"cordova-plugin-sqlite": "0.9.0"
}
// BOTTOM OF METADATA
});